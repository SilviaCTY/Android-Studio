package com.example.silvia.project;

import android.content.DialogInterface;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class Main5Activity extends AppCompatActivity {
    TextView t1,t2,t3;
    Button b1_out,menu_btn,ap_btn,ay_btn;
    double x_down,x_up;
    double total;
    LinearLayout m1,m2,ap_layout,menu_layout;
    int[] CB1_id={R.id.checkBox,R.id.checkBox2,R.id.checkBox3,R.id.checkBox4,R.id.checkBox5,R.id.checkBox6,R.id.checkBox7,R.id.checkBox8,R.id.checkBox9};
    int[] CB2_id={R.id.checkBox10,R.id.checkBox11,R.id.checkBox12};
    ArrayList<CompoundButton> checkButton1;
    ArrayList<CompoundButton> checkButton2;
    FirebaseDatabase database = FirebaseDatabase.getInstance();
    DatabaseReference myRef = database.getReference("Member");
    DataSnapshot MyDs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main5);
        t1=findViewById(R.id.textView_name);
        t2=findViewById(R.id.textView_apply);
        t3=findViewById(R.id.textView_free);
        b1_out=findViewById(R.id.logout_button);
        menu_btn=findViewById(R.id.menu_button);
        ap_btn=findViewById(R.id.Areturn_btn);
        ay_btn=findViewById(R.id.apply_btn);
        m1=findViewById(R.id.menu1);
        m2=findViewById(R.id.menu2);
        ap_layout=findViewById(R.id.apply_layout);
        menu_layout=findViewById(R.id.Amenu_layout);
        checkButton1=new ArrayList<>();
        checkButton2=new ArrayList<>();


        Intent it=getIntent();
        t1.setText("委託人:"+it.getStringExtra("Name"));

        menu_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ap_layout.setVisibility(View.GONE);
                menu_layout.setVisibility(View.VISIBLE);
            }
        });

        ap_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ap_layout.setVisibility(View.VISIBLE);
                menu_layout.setVisibility(View.GONE);
            }
        });

        b1_out.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
             Intent logout=new Intent(Main5Activity.this,MainActivity.class);
             startActivity(logout);
            }
        });

        for (int i=0;i<9;i++) {
            CheckBox cb = findViewById(CB1_id[i]);
            final int j = i + 1;
            cb.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                    if (isChecked == true) {
                        checkButton1.add(buttonView);
                        total += (j * 10);
                    } else {
                        checkButton1.remove(buttonView);
                        total -= (j * 10);
                    }
                    show();
                }
            });
        }
        for (int i=0;i<3;i++) {
            CheckBox cb2 = findViewById(CB2_id[i]);
            final int j = i + 1;
            cb2.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                    if (isChecked == true) {
                        checkButton2.add(buttonView);
                    } else {
                        checkButton2.remove(buttonView);
                    }
                    show();
                }
            });
        }

        ay_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new AlertDialog.Builder(Main5Activity.this).setMessage("是否送出").setPositiveButton("確定", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                Intent it3=getIntent();
                                myRef.child(it3.getStringExtra("Name")).child("Apply").setValue(t2.getText().toString());
                                myRef.child(it3.getStringExtra("Name")).child("Free").setValue(t3.getText().toString());
                                Intent it4=new Intent(Main5Activity.this,MainActivity.class);
                                startActivity(it4);
                                Toast.makeText(Main5Activity.this, "案件已送出", Toast.LENGTH_SHORT).show();
                            }
                        }).show();
            }
        });

        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                MyDs= dataSnapshot;
            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
            }
        });

    }

    public void show(){
        String msg="";
        String msg2="";
        for (CompoundButton a:checkButton1){
            msg+=((TextView)a).getText().toString()+"\n";
        }
        for(CompoundButton a:checkButton2){
            msg2+=((TextView)a).getText().toString()+"\n";
        }
        msg+="金額為:"+total+"萬起";
        msg2+=" ";
        t2.setText(msg);
        t3.setText(msg2);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if(event.getAction()==MotionEvent.ACTION_DOWN){
            x_down=event.getX();
        }
        else if(event.getAction()==MotionEvent.ACTION_UP){
            x_up=event.getX();
        }
        if(x_down<x_up){
            m1.setVisibility(View.GONE);
            m2.setVisibility(View.VISIBLE);
        }
        else {
            m1.setVisibility(View.VISIBLE);
            m2.setVisibility(View.GONE);
        }
        return super.onTouchEvent(event);
    }
}

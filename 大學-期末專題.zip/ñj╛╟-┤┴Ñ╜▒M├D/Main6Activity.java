package com.example.silvia.project;


import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.lang.reflect.Member;

public class Main6Activity extends AppCompatActivity {
    TextView t1,t2,t3;
    Button b1_out;
    Intent it;
    FirebaseDatabase database = FirebaseDatabase.getInstance();
    DatabaseReference myRef = database.getReference("Member");
    DataSnapshot MyDs;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main6);
        t1=findViewById(R.id.textView_apply);
        t2=findViewById(R.id.textView_free);
        t3=findViewById(R.id.textView_Aname);
        b1_out=findViewById(R.id.logout_b2);
        it=getIntent();

        b1_out.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent back = new Intent(Main6Activity.this , Main3Activity.class);
                startActivity(back);
            }
        });
        t3.setText("委託人:"+it.getStringExtra("Name2"));

        myRef.child(it.getStringExtra("Name2")).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for(DataSnapshot aa: dataSnapshot.getChildren()){
                    if(aa.getKey().equals("Apply")){
                        t1.setText(aa.getValue().toString());
                    }
                    else if(aa.getKey().equals("Free")){
                        t2.setText(aa.getValue().toString());
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

    }
}

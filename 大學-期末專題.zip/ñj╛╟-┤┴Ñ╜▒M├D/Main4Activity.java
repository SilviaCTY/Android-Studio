package com.example.silvia.project;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class Main4Activity extends AppCompatActivity {
    Button b1,b2;
    EditText et1,et2,et3,et4;
    FirebaseDatabase database = FirebaseDatabase.getInstance();
    DatabaseReference myRef = database.getReference("Member");
    DataSnapshot MyDs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main4);
        b1=findViewById(R.id.new_button);
        b2=findViewById(R.id.new_b);
        et1=findViewById(R.id.editText_new);
        et2=findViewById(R.id.editText2_new);
        et3=findViewById(R.id.editText3_new);
        et4=findViewById(R.id.editText4_new);


        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent four = new Intent(Main4Activity.this , MainActivity.class);
                startActivity(four);
            }
        });

        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (et1.getText().toString().equals("") && et2.getText().toString().equals("") && et3.getText().toString().equals("")) {
                    Toast.makeText(Main4Activity.this, "不能為空!", Toast.LENGTH_SHORT).show();
                }
                else {
                    if (MyDs.hasChild(et1.getText().toString())) {
                        Toast.makeText(Main4Activity.this, "已有申請過了!!", Toast.LENGTH_SHORT).show();
                    } else if (MyDs.hasChild(et3.getText().toString())) {
                        Toast.makeText(Main4Activity.this, "暱稱已被使用!!", Toast.LENGTH_SHORT).show();
                    }
                    else {
                        if(et2.getText().toString().equals(et4.getText().toString())) {
                            myRef.child(et3.getText().toString()).child("Name").setValue(et3.getText().toString());
                            myRef.child(et3.getText().toString()).child("Email").setValue(et1.getText().toString());
                            myRef.child(et3.getText().toString()).child("Pwd").setValue(et2.getText().toString());
                            Toast.makeText(Main4Activity.this, "申請成功", Toast.LENGTH_SHORT).show();
                            Intent change = new Intent(Main4Activity.this, MainActivity.class);
                            startActivity(change);
                        }
                        else {
                            Toast.makeText(Main4Activity.this, "密碼不一致!!!", Toast.LENGTH_SHORT).show();
                        }
                    }

                }
            }
        });

        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                MyDs=dataSnapshot;
            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
            }
        });
    }

}
package com.example.silvia.project;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;

public class Main2Activity extends AppCompatActivity {
    double x_down,x_up;
    LinearLayout m1,m2;
    Button b1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        m1=findViewById(R.id.menu1);
        m2=findViewById(R.id.menu2);
        b1=findViewById(R.id.button2);

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent two = new Intent(Main2Activity.this , MainActivity.class);
                startActivity(two);
            }
        });
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if(event.getAction()==MotionEvent.ACTION_DOWN){
            x_down=event.getX();
        }
        else if(event.getAction()==MotionEvent.ACTION_UP){
            x_up=event.getX();
        }
        if(x_down<x_up){
            m1.setVisibility(View.GONE);
            m2.setVisibility(View.VISIBLE);
        }
        else {
            m1.setVisibility(View.VISIBLE);
            m2.setVisibility(View.GONE);
        }
        return super.onTouchEvent(event);
    }
}
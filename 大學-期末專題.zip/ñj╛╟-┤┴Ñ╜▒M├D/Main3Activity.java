package com.example.silvia.project;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class Main3Activity extends AppCompatActivity {
    FirebaseDatabase database = FirebaseDatabase.getInstance();
    DatabaseReference myRef = database.getReference("Member");
    DataSnapshot MyDs;
    Button b1,b2,b3,b4;
    EditText et1,et2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);
        b1=findViewById(R.id.login_button);
        b2=findViewById(R.id.login_b);
        b3=findViewById(R.id.inquire);
        b4=findViewById(R.id.loginstar);
        et1=findViewById(R.id.editText_login);
        et2=findViewById(R.id.editText2_login);


        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent three = new Intent(Main3Activity.this , MainActivity.class);
                startActivity(three);
            }
        });

        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(et1.getText().toString().equals("")&&et2.getText().toString().equals("")){
                    Toast.makeText(Main3Activity.this, "不能為空!", Toast.LENGTH_SHORT).show();
                }
                else{
                    if (MyDs.hasChild(et1.getText().toString())) {
                        if(MyDs.child(et1.getText().toString()).child("Pwd").getValue().toString().equals(et2.getText().toString())){
                            Intent it=new Intent(Main3Activity.this,Main5Activity.class);
                            it.putExtra("Name",MyDs.child(et1.getText().toString()).child("Name").getValue().toString());
                            startActivity(it);
                        }
                        else {
                            Toast.makeText(Main3Activity.this, "密碼錯誤!", Toast.LENGTH_SHORT).show();
                        }
                    }
                    else{
                        Toast.makeText(Main3Activity.this, "暱稱錯誤或者您還沒申請會員!", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(et1.getText().toString().equals("")&&et2.getText().toString().equals("")){
                    Toast.makeText(Main3Activity.this, "不能為空!", Toast.LENGTH_SHORT).show();
                }
                else {
                    if (MyDs.hasChild(et1.getText().toString())) {
                        if (MyDs.child(et1.getText().toString()).child("Pwd").getValue().toString().equals(et2.getText().toString())) {
                            Intent it = new Intent(Main3Activity.this, Main6Activity.class);
                            it.putExtra("Name2", MyDs.child(et1.getText().toString()).child("Name").getValue().toString());
                            startActivity(it);
                        } else {
                            Toast.makeText(Main3Activity.this, "密碼錯誤!", Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        Toast.makeText(Main3Activity.this, "暱稱錯誤或者您還沒申請會員!", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

        b4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(et1.getText().toString().equals("")&&et2.getText().toString().equals("")){
                    Toast.makeText(Main3Activity.this, "不能為空!", Toast.LENGTH_SHORT).show();
                }
                else {
                    if (MyDs.hasChild(et1.getText().toString())) {
                        if (MyDs.child(et1.getText().toString()).child("Pwd").getValue().toString().equals(et2.getText().toString())) {
                            Intent it = new Intent(Main3Activity.this, Main8Activity.class);
                            it.putExtra("Name3", MyDs.child(et1.getText().toString()).child("Name").getValue().toString());
                            startActivity(it);
                        } else {
                            Toast.makeText(Main3Activity.this, "密碼錯誤!", Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        Toast.makeText(Main3Activity.this, "暱稱錯誤或者您還沒申請會員!", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                MyDs= dataSnapshot;
            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
            }
        });


    }
}
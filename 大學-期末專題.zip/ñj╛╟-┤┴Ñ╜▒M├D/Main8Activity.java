package com.example.silvia.project;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.RatingBar;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.sql.Array;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class Main8Activity extends AppCompatActivity {
    TextView t1,t2;
    Button bs_1,bs_2,bs_3;
    RatingBar rstar;
    EditText et;
    FirebaseDatabase database = FirebaseDatabase.getInstance();
    DatabaseReference myRef = database.getReference("Member");
    Intent it;
    ListView lv;
    ArrayAdapter<String> apd;
    ArrayList<String> lv_array;
    DataSnapshot MyDs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main8);
        t1=findViewById(R.id.textView_starname);
        t2=findViewById(R.id.textView_starf);
        bs_1=findViewById(R.id.logout_b3);
        bs_2=findViewById(R.id.button_star);
        bs_3=findViewById(R.id.button_r);
        rstar=findViewById(R.id.ratingBar);
        et=findViewById(R.id.editText_star);
        it=getIntent();
        lv=findViewById(R.id.star_listview);
        lv_array=new ArrayList<>();
        apd=new ArrayAdapter<String>(this,R.layout.support_simple_spinner_dropdown_item,lv_array);
        lv.setAdapter(apd);


        t1.setText(it.getStringExtra("Name3")+"您好!");

        rstar.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {
            @Override
            public void onRatingChanged(RatingBar ratingBar, float rating, boolean fromUser) {
                t2.setText(rating+"星");
            }
        });

        bs_1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent star = new Intent(Main8Activity.this , Main3Activity.class);
                startActivity(star);
            }
        });

        bs_2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(t2.getText().toString().equals("")){
                    Toast.makeText(Main8Activity.this, "請選擇星數", Toast.LENGTH_SHORT).show();
                }
                else {
                    Toast.makeText(Main8Activity.this, "謝謝您的支持!", Toast.LENGTH_SHORT).show();
                    myRef.child(it.getStringExtra("Name3")).child("Star").setValue(t2.getText().toString());
                    myRef.child(it.getStringExtra("Name3")).child("Opinion").setValue(et.getText().toString());
                    Intent star = new Intent(Main8Activity.this , Main7Activity.class);
                    startActivity(star);
                }
            }
        });

        bs_3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (t2.getText().toString().equals("")) {
                    Toast.makeText(Main8Activity.this, "請選擇星數", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(Main8Activity.this, "修改成功!", Toast.LENGTH_SHORT).show();
                    myRef.child(it.getStringExtra("Name3")).child("Star").setValue(t2.getText().toString());
                    myRef.child(it.getStringExtra("Name3")).child("Opinion").setValue(et.getText().toString());
                }
            }
        });

        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Toast.makeText(Main8Activity.this, "更改評論", Toast.LENGTH_SHORT).show();
                et.setText(((TextView)view).getText().toString());
            }
        });

        myRef.child(it.getStringExtra("Name3")).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                apd.clear();
                MyDs= dataSnapshot;
                for (DataSnapshot ss : dataSnapshot.getChildren()) { {
                        if (ss.getKey().equals("Opinion")) {
                                apd.add(ss.getValue().toString());
                        }
                }
            }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }
}
